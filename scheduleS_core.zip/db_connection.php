<?php
//Database Connection File.
$host = "localhost";//bctreeschedule.db.9982491.hostedresource.com
$user = "bctreeschedule";//bctreeschedule
$pssw = "greenSouls6#";
$db = "bctreeschedule";//bctreeschedule
$link = mysqli_connect($host, $user, $pssw,$db);

//die('Could not connect: ' . mysqli_error($link));

//echo 'Connected successfully';
//mysql_close($link);

?>