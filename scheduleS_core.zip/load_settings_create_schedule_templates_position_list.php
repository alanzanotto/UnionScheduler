<?php
//Include database Connection Script
include 'db_connection.php';

//Retrieve POST Values
$template_ID = $_POST["requested_template_ID"];

if ( $template_ID == "" )
{
echo "Please Select a template to display...";
}
else
{
//echo "The template ID is set to: " . $template_ID;


//NEW SQL TO FOR FACILITY & STATION

//RETREIVE TEMPLATE SCHEDULE POSITIONS FOR DAY SHIFT
$sql_template_position_list_day = '
SELECT * 
FROM `'.$db.'`.`schedule_template_position_list`
WHERE shift = 0 
AND ID_template = '.$template_ID;

$result_template_position_list_day = $link->query($sql_template_position_list_day);



echo 
'
<div data-role="collapsible" data-inset="false">
	<h3>Day</h3>
		<ul data-role="listview">';


while ($row = $result_template_position_list_day->fetch_assoc())
{
$stpl_ID_schedule_position = $row['ID_schedule_position'];
$stpl_quantity = $row['quantity'];
$stpl_shift = $row['shift'];
//retrieve position name from schedule position table
$sql_position_name = '
SELECT name, facility, station
FROM `'.$db.'`.`schedule_position`
WHERE ID = '.$stpl_ID_schedule_position;
$result_position_name = $link->query($sql_position_name);
$object_position_name = $result_position_name->fetch_assoc();
$stpl_position_namae = $object_position_name['name'];
$stpl_position_facility = $object_position_name['facility'];

echo '
	<li>
		<a href="#popupEditPosition" 
			onClick="update_popup_edit_position('.$stpl_ID_schedule_position.', \''.$stpl_position_namae.'\', '.$stpl_quantity.', '.$stpl_shift.'
			)" 
			class="ui-icon-edit" data-rel="popup" 
			data-position-to="window" 
			data-transition="pop">'.$stpl_position_namae.'<span class="ui-li-count">'.$stpl_quantity.' </span>
		</a>
	</li>';
	
		
}//while day

echo '	</ul>
</div><!-- /collapsible -->';


echo 
'<div data-role="collapsible" data-inset="false">
	<h3>Night</h3>
	<ul data-role="listview">';

	
	
//RETREIVE TEMPLATE SCHEDULE POSITIONS FOR NIGHT SHIFT
$sql_template_position_list_night = '
SELECT * 
FROM `'.$db.'`.`schedule_template_position_list`
WHERE shift = 1 
AND ID_template = '.$template_ID;

$result_template_position_list_night = $link->query($sql_template_position_list_night);

while ($row = $result_template_position_list_night->fetch_assoc())
{
$stpl_ID_schedule_position = $row['ID_schedule_position'];
$stpl_quantity = $row['quantity'];
$stpl_shift = $row['shift'];
//retrieve position name from schedule position table
$sql_position_name = '
SELECT name
FROM `'.$db.'`.`schedule_position`
WHERE ID = '.$stpl_ID_schedule_position;
$result_position_name = $link->query($sql_position_name);
$object_position_name = $result_position_name->fetch_assoc();
$stpl_position_namae = $object_position_name['name'];

echo '
	<li>
		<a href="#popupEditPosition"
			onClick="update_popup_edit_position('.$stpl_ID_schedule_position.', \''.$stpl_position_namae.'\', '.$stpl_quantity.', '.$stpl_shift.'
			)" 
			class="ui-icon-edit" data-rel="popup" 
			data-position-to="window"
			data-transition="pop">'.$stpl_position_namae.'<span class="ui-li-count">'.$stpl_quantity.'</span>
		</a>
	</li>';
	
		
}//while night
		
		
echo '</ul>
</div><!-- /collapsible -->';



//Echo the NEW POSITION POPUP
echo '
	<div data-role="popup" id="popupNewPosition" data-theme="a" class="ui-corner-all">
    <form>
		<div style="padding: 5px 10px;">
		<h3>New Position for Template:</h3>
			<select name="select-choice-newPosition" id="select-choice-newPosition">
			<option value="">Choose Position</option>';
			
//RETRIEVE POSITIONS  FROM DATABSE
$sql_schedule_position = 
"
SELECT ID, name, facility
FROM `".$db."`.`schedule_position`
";
echo $sql_schedule_position;
$result_schedule_position = $link->query($sql_schedule_position);
//ECHO POSITION INTO SELECT LIST

while ($row = $result_schedule_position->fetch_assoc())
{
$position_ID = $row['ID'];
$position_name = $row['name'];
$position_facility_ID = $row['facility'];
$sql_facility_name = "
SELECT name
FROM `".$db."`.`schedule_facility`
WHERE ID = ".$position_facility_ID;
$result_facility_name = $link->query($sql_facility_name);
$object_facility_name = $result_facility_name->fetch_assoc();
$position_facility_name = $object_facility_name['name'];

echo '<option value="'.$position_ID.'">'.$position_name.' ('.$position_facility_name.')</option>';
}			
echo '</select>
			<label for="slider-fill">Quantity:</label>
			<input type="range" name="slider-fill" id="slider-fill_newPosition" value="1" min="1" max="50" data-highlight="true">

		<fieldset data-role="controlgroup" data-type="horizontal" >
		    <legend>Shift:</legend>
		        <input type="radio" name="radio-choice_newPosition" id="radio-choice-day" value="0" checked="checked">
		        <label for="radio-choice-day">Day</label>
		        <input type="radio" name="radio-choice_newPosition" id="radio-choice-night" value="1">
		        <label for="radio-choice-night">Night</label>
		</fieldset>

		</br><hr>
		<a href="#settings_create_schedule_templates_page" data-role="button" data-icon="check" data-inline="true" onClick="update_settings_edit_template_position_new()">Save</a>
		<a href="#settings_create_schedule_templates_page" data-role="button"  data-inline="true">Cancel</a>

		</div>
	</form>
	';


//Echo the EDIT POSITION POPUP	
echo '
	<div data-role="popup" id="popupEditPosition" data-theme="a" class="ui-corner-all">
    <form>
		<div style="padding: 5px 10px;">
		<h3 id="editPositionHeader">Edit Position:<label></label></h3>
			 <input type="hidden" id="hiddenPositionID"  value="">
			<label for="slider-fill">Quantity:</label>
			<input type="range" name="slider-fill" id="slider-fill_editPosition" value="1" min="1" max="50" data-highlight="true">

		<fieldset data-role="controlgroup" data-type="horizontal" >
		    <legend>Shift:</legend>
		        <input type="radio" name="radio-choice_editPosition" id="radio-choice-day_editPosition" value="0">
		        <label for="radio-choice-day_editPosition">Day</label>
		        <input type="radio" name="radio-choice_editPosition" id="radio-choice-night_editPosition" value="1">
		        <label for="radio-choice-night_editPosition">Night</label>
		</fieldset>

		</br><hr>
		<a href="#settings_create_schedule_templates_page" data-role="button" data-icon="check" data-inline="true" onClick="update_settings_edit_template_position_save()">Save</a>
		<a href="#settings_create_schedule_templates_page" data-role="button" data-icon="delete" data-inline="true" onClick="update_settings_edit_template_position_delete()">Remove</a>
		<a href="#settings_create_schedule_templates_page" data-role="button"  data-inline="true">Cancel</a>

		</div>
	</form>
	</div>
';


}//else




//Include database Termination Script
include 'db_disconnect.php';
?>