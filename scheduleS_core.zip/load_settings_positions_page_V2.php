<?php
//Include database Connection Script
include 'db_connection.php';



//select all the current schedule_positions in the database.
$sql_all_schedule_positions = 
"
SELECT *
FROM `".$db."`.`schedule_position`
ORDER BY  `ID` ASC
";
$result_all_schedule_positions = $link->query($sql_all_schedule_positions);


//Setup Posted Position Requirement Index.	
$sql_posted_positions_list_V2 = 
"
SELECT *
FROM `".$db."`.`posted_positions`
";
//echo $sql_posted_positions_list_V2;
$result0_posted_positions_list_results = $link->query($sql_posted_positions_list_V2);
$result1_posted_positions_list_results = $link->query($sql_posted_positions_list_V2);
$result2_posted_positions_list_results = $link->query($sql_posted_positions_list_V2);


//Setup SQL for schedule_facility
$sql_schedule_facility = "
SELECT * 
FROM `".$db."`.`schedule_facility`
";
$result1_schedule_facility = $link->query($sql_schedule_facility);
$result2_schedule_facility = $link->query($sql_schedule_facility);

//Setup SQL for schedule_station
$sql_schedule_station = "
SELECT * 
FROM `".$db."`.`schedule_station`
";
$result1_schedule_station = $link->query($sql_schedule_station);
$result2_schedule_station = $link->query($sql_schedule_station);

//display all the current schedule_positions in the database.
//output the results
echo 
'
<div data-role="collapsible" data-inset="false">
	<h3>Schedule Positions</h3>
		<ul data-role="listview">';

while ($row = $result_all_schedule_positions->fetch_assoc())
{
//Assign variables
$schedule_position_ID = $row['ID'];
$schedule_position_ID_posted_position_requirement = $row['ID_posted_position_requirement'];
$schedule_position_name = $row['name'];
$schedule_position_non_rotational = $row['non_rotational'];
$schedule_position_non_rotational_english;

if ($schedule_position_non_rotational == 0)
$schedule_position_non_rotational_english = "No";
else
$schedule_position_non_rotational_english = "Yes";


$schedule_position_ID_facility = $row['facility'];
$schedule_position_ID_station = $row['station'];

//Get Facility & Station Name
$sql_facility_name = 
"SELECT name 
FROM `".$db."`.`schedule_facility`
WHERE ID = ".$schedule_position_ID_facility;
$result_facility_name = $link->query($sql_facility_name);
$object_facility_name = $result_facility_name->fetch_assoc();
$schedule_facility_name = $object_facility_name['name'];

//retrieve posted position name.
$sql_posted_position_name = '
SELECT name
FROM `'.$db.'`.`posted_positions`
WHERE ID = '.$schedule_position_ID_posted_position_requirement;
$result_posted_position_name = $link->query($sql_posted_position_name);
$object_posted_position_name = $result_posted_position_name->fetch_assoc();
$schedule_position_PP_name = $object_posted_position_name['name'];

echo '
	<li>
		<a href="#editPopupSchedulePosition" 
			onClick="update_edit_popup_schedule_position('.$schedule_position_ID.', \''.$schedule_position_name.'\', '.$schedule_position_ID_posted_position_requirement.', '.$schedule_position_non_rotational.', '.$schedule_position_ID_facility.', '.$schedule_position_ID_station.')" 
			class="ui-icon-edit" data-rel="popup" 
			data-position-to="window" 
			data-transition="pop">'.$schedule_position_name.'<span class="ui-li-count">'.$schedule_facility_name.'</span>
		</a>
	</li>';

}
echo '	</ul>
</div><!-- /collapsible -->';




//Echo the NEW POSITION POPUP	

echo '
	<div data-role="popup" id="newPopupSchedulePosition" data-theme="a" class="ui-corner-all">
    <form>
		<div style="padding: 5px 10px;">
		
		<h3 id="newPopupNewSchedulePositionHeader">New Position:<label></label></h3>
		
		<input type="text" name="text-basic" id="newPopupSchedulePositionName" value="" placeholder="Position Name (Optional Description)">

		<select name="select-choice-mini" id="newPopupSchedulePositionPPRequirement" data-mini="true" data-inline="true">
		<option value="">Posted Position</option>';

while ($row_posted_position_list = $result1_posted_positions_list_results->fetch_assoc())
{
//load current posted position value.
$posted_position_ID = $row_posted_position_list['ID'];
$posted_position_list = $row_posted_position_list['posted_position'];
$posted_position_name = $row_posted_position_list['name'];
//Echo the entry.
echo '<option value="' . $posted_position_ID . '" ';
//if selected make this the value.

echo '>' . $posted_position_name . '</option>';
}


echo '
		</select>
		
		<select name="select-choice-mini" id="newPopupSchedulePositionFacility" data-mini="true" data-inline="true">
		<option value="">Facility</option>';
while ($row = $result1_schedule_facility->fetch_assoc())
{
//load up variables
$facility_ID = $row['ID'];
$facility_name = $row['name'];
echo '<option value="' . $facility_ID . '" ';
echo '>' . $facility_name . '</option>';
}
echo '
		</select>
		
		
		<select name="select-choice-mini" id="newPopupSchedulePositionStation" data-mini="true" data-inline="true">
		<option value="">Station</option>';
while ($row = $result1_schedule_station->fetch_assoc())
{
//load up variables
$station_ID = $row['ID'];
$station_name = $row['name'];
echo '<option value="' . $station_ID . '" ';
echo '>' . $station_name . '</option>';
}
		

echo '
		</select>
		
		</br><hr>
		
		<label for="slider-flip-m" data-inline="true">Non Rotational:</label>
		<select data-inline="true" name="slider-flip-m" id="newPopupSchedulePositionNonRotational" data-role="slider" data-mini="true">
		<option value="0">No</option>
		<option value="1">Yes</option>
		</select>
		
		</br><hr>
		<a href="#settings_positions_page" data-role="button" data-icon="check" data-inline="true" onClick="update_settings_edit_position_new()">Save</a>
		<a href="#settings_positions_page" data-role="button"  data-inline="true">Cancel</a>

		</div>
	</form>
	</div>
';






//Echo the EDIT POSITION POPUP	
echo '
	<div data-role="popup" id="editPopupSchedulePosition" data-theme="a" class="ui-corner-all">
    <form>
		<div style="padding: 5px 10px;">
		
		
		<h3 id="editPopupSchedulePositionHeader">Edit Position:<label></label></h3>
		<input type="hidden" name="schedule_id_hidden" id="editPopupSchedulePositionHidden" value="">
		<input type="text" name="text-basic" id="editPopupSchedulePositionName" value="" placeholder="Position Name (Optional Description)">

		<select name="select-choice-mini" id="editPopupSchedulePositionPPRequirement" data-mini="true" data-inline="true">
		<option value="">Posted Position</option>';
while ($row_posted_position_list = $result2_posted_positions_list_results->fetch_assoc())
{
//load current posted position value.
$posted_position_ID = $row_posted_position_list['ID'];
$posted_position_list = $row_posted_position_list['posted_position'];
$posted_position_name = $row_posted_position_list['name'];
//Echo the entry.
echo '<option value="' . $posted_position_ID . '" ';
//if selected make this the value.

echo '>' . $posted_position_name . '</option>';
}

echo '
		</select>
		
		<select name="select-choice-mini" id="editPopupSchedulePositionFacility" data-mini="true" data-inline="true">
		<option value="">Facility</option>';
		
while ($row = $result2_schedule_facility->fetch_assoc())
{
//load up variables
$facility_ID = $row['ID'];
$facility_name = $row['name'];
echo '<option value="' . $facility_ID . '" ';
echo '>' . $facility_name . '</option>';
}

echo '
		</select>
		
		
		<select name="select-choice-mini" id="editPopupSchedulePositionStation" data-mini="true" data-inline="true">
		<option value="">Station</option>';
		
while ($row = $result2_schedule_station->fetch_assoc())
{
//load up variables
$station_ID = $row['ID'];
$station_name = $row['name'];
echo '<option value="' . $station_ID . '" ';
echo '>' . $station_name . '</option>';
}
echo '
		</select>
		
		</br><hr>
		
		<label for="slider-flip-m" data-inline="true">Non Rotational:</label>
		<select data-inline="true" name="slider-flip-m" id="editPopupSchedulePositionNonRotational" data-role="slider" data-mini="true">
		<option value="0">No</option>
		<option value="1">Yes</option>
		</select>
		
		</br><hr>
		<a href="#settings_positions_page" data-role="button" data-icon="check" data-inline="true" onClick="update_settings_edit_position_save()">Save</a>
		<a href="#settings_positions_page" data-role="button"  data-inline="true">Cancel</a>

		</div>
	</form>
	</div>
';

//Include database Termination Script
include 'db_disconnect.php';
?>
