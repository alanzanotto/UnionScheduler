<?php
//Include database Connection Script
include 'db_connection.php';

//retrive post variables
$new_position_name = $_POST['new_position_name'];
$new_pp_requirement = $_POST['new_pp_requirement'];
$new_facility = $_POST['new_facility'];
$new_station = $_POST['new_station'];
$new_non_rotational = $_POST['new_non_rotational'];


$sql_update_schedule_position = "

INSERT INTO `".$db."`.`schedule_position` (`ID`, `ID_posted_position_requirement`, `name`, `non_rotational`, `facility`, `station`) 
VALUES (NULL, '".$new_pp_requirement."', '".$new_position_name."', '".$new_non_rotational."', '".$new_facility."', '".$new_station."')";

$link->query($sql_update_schedule_position);

//Include database Termination Script
include 'db_disconnect.php';
?>