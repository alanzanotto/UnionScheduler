<?php
//Include database Connection Script
include 'db_connection.php';

//retrive post variables
$position_id = $_POST['position_id'];
$new_position_name = $_POST['new_position_name'];
$new_pp_requirement = $_POST['new_pp_requirement'];
$new_facility = $_POST['new_facility'];
$new_station = $_POST['new_station'];
$new_non_rotational = $_POST['new_non_rotational'];


$sql_update_schedule_position = "
UPDATE `".$db."`.`schedule_position` 
SET 
`ID_posted_position_requirement` = ".$new_pp_requirement.", 
`name` = '".$new_position_name."', 
`non_rotational` = ".$new_non_rotational.",
`facility` = ".$new_facility.",
`station` = ".$new_station."
WHERE `schedule_position`.`ID` = ".$position_id;

$link->query($sql_update_schedule_position);

//Include database Termination Script
include 'db_disconnect.php';
?>