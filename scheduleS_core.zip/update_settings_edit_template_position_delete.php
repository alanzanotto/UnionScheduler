<?php
//Include database Connection Script
include 'db_connection.php';

//retrive post variables
$template_ID = $_POST['template_ID'];
$position_ID = $_POST['position_ID'];
$position_shift = $_POST['position_shift'];
$position_quantity = $_POST['position_quantity'];

//Check for duplicate entries.
$sql_check_rows = 
"
SELECT *
FROM `".$db."`.`schedule_template_position_list`
WHERE ID_template = ".$template_ID." 
AND ID_schedule_position = ".$position_ID."
AND shift = ".$position_shift; 
$result_check_rows = $link->query($sql_check_rows);

/*
$sql_insert_row = "
INSERT INTO `".$db."`.`schedule_template_position_list`
(ID_template, ID_schedule_position, quantity, shift) 
VALUES (".$template_ID.", ".$position_ID.", ".$position_quantity.", ".$position_shift.")
";
echo $sql_insert_row;
*/

$row_count = mysqli_num_rows($result_check_rows);
echo $row_count;
if ( $row_count > 1 )
{
echo $row_count;
//delete all rows ....
$sql_delete_row = 
"
DELETE FROM `".$db."`.`schedule_template_position_list`
WHERE ID_template = ".$template_ID."
AND ID_schedule_position = ".$position_ID."
AND shift = ". $position_shift;
$link->query($sql_delete_row);
//...and re enter 1. 
$sql_insert_row = 
"
INSERT INTO `".$db."`.`schedule_template_position_list`
(ID_template, ID_schedule_position, quantity, shift) 
VALUES (".$template_ID.", ".$position_ID.", ".$position_quantity.", ".$position_shift.")
";

$link->query($sql_insert_row);

}
else
{
//delete the row
$sql_delete_row = 
"
DELETE FROM `".$db."`.`schedule_template_position_list`
WHERE ID_template = ".$template_ID."
AND ID_schedule_position = ".$position_ID."
AND shift = ". $position_shift;
$link->query($sql_delete_row);
}





//Include database Termination Script
include 'db_disconnect.php';
?>