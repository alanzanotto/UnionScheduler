<?php
//Include database Connection Script
include 'db_connection.php';



$date_today = date("Y-m-d");
$date_tomorrow = date("Y-m-d", strtotime($date_today . ' + 1 day') );
echo 
'
<p>This is the Schedule Setup Page</p>
		<p>Fill in the following information to create a schedule:</p>
		
		<label for="text-basic">Date (YYYY-MM-DD):</label>
		<input type="text" name="text-basic" id="text-date" value="'.$date_tomorrow.'" placeholder="YYYY-MM-DD">
		<label for="select-choice-1" class="select">Schedule Template:</label>
		<select name="select-choice-1" id="select-schedule_template">';
		
$sql_select_templates = "SELECT * FROM `".$db."`.`schedule_template`";
$result_select_templates = $link->query($sql_select_templates);

while ($object_select_templates = $result_select_templates->fetch_assoc())
{
$template_ID = $object_select_templates['ID'];
$template_name = $object_select_templates['name'];
echo '<option value="'.$template_ID.'">'.$template_name.'</option>';
}
echo '</select>';
echo '<div data-role="content" id="schedule_setup_page_content2">';
echo '<a href="#" class="ui-btn ui-corner-all" id="anchor-button" onClick="create_schedule(document.getElementById(\'text-date\').value, document.getElementById(\'select-schedule_template\').value)">Create</a>';
echo '</div><!-- /content -->';


//Include database Termination Script
include 'db_disconnect.php';
?>