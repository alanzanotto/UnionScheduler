<?php
//Include database Connection Script
include 'db_connection.php';


echo 
'
<div data-role="popup" id="popupNewTemplate" data-theme="a" class="ui-corner-all">
<form>
	<div style="padding:10px 20px;">
		<h3>Create New Template</h3>
		
		<input type="text" id="newTemplateName" value="" placeholder="Name    Example: Cherries (Day/Night) " data-theme="a">
		<label for="select-choice_newTemplateReplication" class="select">Replication:</label>
		<select name="select-choice_newTemplateReplication" id="select-choice_newTemplateReplication">
			<option value="blank">Blank</option>';
		
			$sql_select_templates = "SELECT * FROM `".$db."`.`schedule_template`";
			$result_select_templates = $link->query($sql_select_templates);
			
			while ($object_select_templates = $result_select_templates->fetch_assoc())
			{
			$template_ID = $object_select_templates['ID'];
			$template_name = $object_select_templates['name'];
			echo '<option value="'.$template_ID.'">'.$template_name.'</option>';
			}
			
echo '
		</select>
		
		</br><hr>
		<a href="#settings_schedule_templates_page" data-role="button" data-icon="check" data-inline="true" onClick="update_settings_schedule_template_new()">Save</a>
		<a href="#settings_schedule_templates_page" data-role="button"  data-inline="true">Cancel</a>
        </div>
    </form>
</div>
';



echo '<ul data-role="listview" data-filter="false" data-filter-placeholder="Search fruits..." data-inset="true">';

$sql_select_templates = "SELECT * FROM `".$db."`.`schedule_template`";
$result_select_templates = $link->query($sql_select_templates);

while ($object_select_templates = $result_select_templates->fetch_assoc())
{
$template_ID = $object_select_templates['ID'];
$template_name = $object_select_templates['name'];
echo '<li data-icon="edit"><a href="#" >'.$template_name.'</a></li>';
}
echo '</ul>';

//EDIT POPUP
//RENAME TEMPLATE 
//DELETE (WARNING> THIS WILL DELETE...
//...ALL SAVED TEMPLATES THAT USED THIS TEMPLATE


//Include database Termination Script
include 'db_disconnect.php';
?>